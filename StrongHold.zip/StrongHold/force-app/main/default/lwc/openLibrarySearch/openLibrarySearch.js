import { LightningElement, wire, track, api } from 'lwc';
import getBooks from '@salesforce/apex/OpenLibrarySearchHandler.getBooks';

const columns = [
    { label: 'Book Name', fieldName: 'bookTitle' },
    { label: 'Author', fieldName: 'bookAuthor' },
    { label: 'Link to Open Library Page', fieldName: 'bookId', type: 'url', typeAttributes: { label: 'Go to Book Page', target: 'bookId' }}
];

export default class OpenLibrarySearch extends LightningElement {
    columns = columns;
    @api bookName;
    @track booksList;
    @track error;

    @wire(getBooks, {bookName: '$bookName'})
    wiredBooksList({error, data}){
        if(data){
            this.booksList = data;
        }
        else if(error){
            console.log(error);
            this.error = error;
        }
    }

    handleChange(event){
        const bookName = event.target.value;
        this.bookName = bookName;
        this.delayTimeOut = setTimeout(() => {
            this.bookName = bookName;
        }, 300);
        console.log('bookName= ', this.bookName);
        
    }

}